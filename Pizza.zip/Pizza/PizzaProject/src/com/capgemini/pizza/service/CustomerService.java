package com.capgemini.pizza.service;


import com.capgemini.pizza.bean.Pizza;
import com.capgemini.pizza.dao.CustomerDAOImpl;
import com.capgemini.pizza.dao.ICustomerDAO;
import com.capgemini.pizza.dao.OrderDetailsDAOImpl;
import com.capgemini.pizza.exception.PizzaException;

public class CustomerService implements ICustomerService{
//private IOrderDetailsDAO orderDAO=new OrderDetailsDAOImpl();
private ICustomerDAO customerDAO = new CustomerDAOImpl();
	@Override
	public Long addCustomerDetails(String customerName, String address,
			Long phoneNumber, Double totalPrice,Integer quantity) throws PizzaException {
		
		try{
			
		Long customerId =customerDAO.addCustomerDetails(customerName, address, phoneNumber, totalPrice,quantity);
		
		
		return customerId;
	
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}

}
