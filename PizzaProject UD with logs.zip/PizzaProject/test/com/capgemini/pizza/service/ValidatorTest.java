package com.capgemini.pizza.service;

import static org.junit.Assert.assertTrue;

import org.junit.Ignore;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ValidatorTest {
@Ignore
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}
@Ignore
	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}
@Ignore
	@BeforeEach
	void setUp() throws Exception {
	}
@Ignore
	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testIsValidCustomerName() {
		assertTrue(new Validator().isValidCustomerName("Ravi Kumar"));
	}

	@Test
	void testIsValidCustomerMobile() {
		assertTrue(new Validator().isValidCustomerMobile(9898989898L));
	}

}
