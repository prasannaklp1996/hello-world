package com.capgemini.pizza.bean;

import java.sql.Date;
import java.time.LocalDate;

public class PizzaOrder {
	private Long orderId;
	private Long customerId;
	private Double totalPrice;
	private Date pDate;
	
	public PizzaOrder() {
		super();
	}

	public PizzaOrder(Long orderId, Long customerId, Double totalPrice,
			Date pDate) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.totalPrice = totalPrice;
		this.pDate = pDate;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Date getpDate() {
		return pDate;
	}

	public void setpDate(Date date) {
		this.pDate = date;
	}

	@Override
	public String toString() {
		return "PizzaOrder "
				+ "orderId=" + getOrderId() + ", "
				+ "customerId=" + getCustomerId()
				+ ", totalPrice=" + getTotalPrice() + ", "
				+ "pDate=" + getpDate();
	}
	

}
