package com.capgemini.pizza.service;

import com.capgemini.pizza.exception.PizzaException;

public interface ICustomerService {
	public abstract Long addCustomerDetails(String customerName,String address,Long phoneNumber,Double totalPrice,Integer quantity)throws PizzaException; 
}
