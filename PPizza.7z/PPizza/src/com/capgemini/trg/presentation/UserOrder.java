package com.capgemini.trg.presentation;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.trg.bean.Customer;
import com.capgemini.trg.bean.PizzaOrder;
import com.capgemini.trg.dao.CustomerOrder;
import com.capgemini.trg.dao.ICustomerOrderDao;
import com.capgemini.trg.exception.PizzaException;
import com.capgemini.trg.service.IPizzaOrderService;
import com.capgemini.trg.service.PizzaOrderServiceImp;
import com.capgemini.trg.service.Validator;

public class UserOrder {

	public static Scanner sc=new Scanner(System.in);
	public static Customer customer;
	public static void main(String[] args) throws PizzaException{

		private static IPizzaOrderService orderservice=new PizzaOrderServiceImp();
		PizzaOrder order=new PizzaOrder();
		Validator validator=new Validator();
		private static ICustomerOrderDao customerOrderDao=new CustomerOrder();
		Double pizzaToppingsPrice=0.0;
		Double basePizzaPrice=0.00;
		int option;
		String cname; 
		String address;
		Long phnnumber; 
		while(true){

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("  Pizza Order System  ");
			System.out.println("_______________________________\n");
			System.out.println("1.Place Order");
			System.out.println("2.Display Your Order");
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			option = sc.nextInt();

			try {

				switch (option) {
				case 1:
					System.out.println("Enter customer mobile number");
					Long phnnumber = sc.nextLong();
					System.out.println("Enter customer name:");
					cname = sc.next();
					System.out.println("Enter customer Address");
                    address = sc.next();
					}
					System.out.println("Enter the Pizza Topping preffered:"
							+ "Capsicum,"+"\n"
							+ "mushroom,"+"\n"
							+ "Jalapeno,"+"\n"
							+ "Paneer");
					String topping=sc.next();
					switch (topping) {
					case "Capsicum":
						pizzaToppingsPrice=30.0;
						break;
					case "MushRoom":
						pizzaToppingsPrice=50.0;
						break;
					case "Jalapeno":
						pizzaToppingsPrice=70.0;
						break;

					case "Paneer":
						pizzaToppingsPrice=85.0;
						break;
						
					default:
						System.out.println("Preffered Pizza Toppings are Invalid");
						
					}
					System.out.println("Enter the quantity of required mobileid");
					Integer quantity=sc.nextInt();
					
					Double totalPrice=(quantity*basePizzaPrice) + pizzaToppingsPrice;
					System.out.println("Price:(To be calculated :Rs "+ quantity*basePizzaPrice + " + " + pizzaToppingsPrice + "("
							+ topping + ")=" + totalPrice);
					if(validator.isValidCustomerName(cname)){
						//System.out.println("1");
						if(validator.isValidCustomerMobile(phnnumber)){
							//System.out.println("2");
							int customerId=customerOrderDao.customerDetails(cname, address, phnnumber, totalPrice);
							System.out.println("Customer id: "+customerId);
						
							int orderId= orderservice.getOrderDetails(orderId,customerId, totalPrice);
							//System.out.println("order");
							//PizzaOrder order=orderService.getOrderDetails(orderId);
							System.out.println("Your order is placed...");
							System.out.println("Your order id is: "+orderId);
						}else{
							System.out.println("Enter valid phone number");
						}
					}else{
						System.out.println("Enter valid customer name");
					}
					break;	
				case 2:
					    System.out.println("please enter your order id");
					    Long orderid=sc.nextLong();
					    if(){
					    
				

				}//end of switch


			}catch(Exception e){

			}
			
			
		}//end of while
	}
}


		
		
	}
	}
