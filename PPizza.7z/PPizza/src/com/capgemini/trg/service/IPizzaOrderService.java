package com.capgemini.trg.service;

import java.util.List;

import com.capgemini.trg.bean.PizzaOrder;
import com.capgemini.trg.exception.PizzaException;


public interface IPizzaOrderService {

	
	public List<PizzaOrder> getOrderDetails(int orderId,int customerId,double totalprice) throws PizzaException;

	
}
