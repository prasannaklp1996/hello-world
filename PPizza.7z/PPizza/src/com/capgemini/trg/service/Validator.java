package com.capgemini.trg.service;

import java.util.regex.Pattern;

public class Validator {
	
	public Validator(){
			
		}
	public  Boolean isValidCustomerName(String name){
		String regex1="^[A-Z][a-zA-Z ]{0,19}$";
		 //String regex1="^[a-zA-Z]+(.)?([a-zA-Z]+)?(\\s)?(([a-zA-Z])+)?$";
		 
		 
	 
		return Pattern.matches(regex1,name);
		
	}
	public Boolean isValidCustomerMobile(Long phnnumber){
		String regex="^[1-9][0-9]{9}$";
		 String mobile= Long.toString(phnnumber);

		return Pattern.matches(regex,mobile);
	}
	/*public Boolean isValidOrderId(Long orderId){
		PizzaOrder order=new PizzaOrder();
		if(order.getOrderId()==orderId){
		return true;
		
	}
		return false;
	}*/
	}



