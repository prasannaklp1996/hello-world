package com.capgemini.trg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.trg.exception.PizzaException;
import com.capgemini.trg.utility.DBConnection;

public class CustomerOrder implements ICustomerOrderDao{

	@Override
	public int customerDetails(String custName, String address, Long phone,Double totalprice)  throws PizzaException{

		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(QueryMapper.ADD_CUSTOMER_DETAILS);
				
				Statement statement=connection.createStatement();	
			){
				preparedStatement.setString(1, custName);
				preparedStatement.setString(2, address);
				preparedStatement.setLong(3, phone);
				int n=preparedStatement.executeUpdate();
				if(n>0) {
				 int orderid=new CustomerOrder().orderingPizza(totalprice);
				 return orderid;
				}
				}catch(SQLException e){
					throw new PizzaException("unable to enter details in customer table");
					
		}
		return 0;
	}
	@Override
	public int orderingPizza(double totalprice) throws PizzaException{

		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement2=connection.prepareStatement(QueryMapper.ADD_PIZZA_DETAILS);
                Statement statement=connection.createStatement();
				){
			preparedStatement2.setDouble(1,totalprice);
			int n=preparedStatement2.executeUpdate();
			if(n>0){
				ResultSet rs=statement.executeQuery(QueryMapper.RETRIEVE_ORDER_ID);
				if(rs.next()){
					return rs.getInt(1);
				}
			}
		}catch(SQLException e){
			throw new PizzaException("unable to enter details in order tabkle");
		
		
	}
		return 0;

}
}