package com.capgemini.trg.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.trg.bean.PizzaOrder;
import com.capgemini.trg.exception.PizzaException;
import com.capgemini.trg.utility.DBConnection;

public class OrderIdDetails implements Iorder{

	@Override
	public List<PizzaOrder> getOrderDetails(int orderId, int customerId,
			double totalprice) throws PizzaException {
		
		
		try(
				Connection connection=DBConnection.getConnection();	
				Statement statement=connection.createStatement();
				){
			ResultSet resultSet=
					statement.executeQuery(QueryMapper.GET_ORDER_DETAILS);
			List<PizzaOrder> pizzaorderlist=new ArrayList<>();
			if(resultSet.next()){
				PizzaOrder pizza=new PizzaOrder();
				populateOrderList(pizza,resultSet);
				pizzaorderlist.add(pizza);
			return pizzaorderlist;
			}
		}catch(SQLException e){
			throw new PizzaException("unable to get order details");
		}
		return null;
		
		
	}
private static void populateOrderList(PizzaOrder pizza, ResultSet resultSet) throws SQLException {
		
		
		pizza.setOrderId(resultSet.getInt("orderid"));
		pizza.setCustomerId(resultSet.getInt("customerId"));
		pizza.setTotalprice(resultSet.getDouble("totalprice"));
		
		
	}

}
