package com.capgemini.trg.dao;

public class QueryMapper {

	public static final String GET_ORDER_DETAILS="SELECT * from orderid where order_id=?";
	public static final String ADD_CUSTOMER_DETAILS="insert into customer values(customer_id.NEXTVAL,?,?,?)";
	public static final String ADD_PIZZA_DETAILS="insert into pizzaorder values(order_id.NEXTVAL,customer_id.CURRVAL,?)";
	public static final String RETRIEVE_CUSTOMER_ID="SELECT customer_id.CURRVAL from dual";
	public static final String RETRIEVE_ORDER_ID="SELECT order_id.CURRVAL from dual";
}


	

