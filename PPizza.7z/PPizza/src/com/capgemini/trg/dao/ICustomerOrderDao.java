package com.capgemini.trg.dao;

import com.capgemini.trg.exception.PizzaException;

public interface ICustomerOrderDao {

	public int customerDetails(String custName,String address,Long phone,Double totalprice) throws PizzaException;
	public int orderingPizza(double totalprice) throws PizzaException;
	
}
